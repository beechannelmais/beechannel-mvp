# BeeChannel+ MVP (Next.js)
Como rodar:
1) Node 18+ instalado
2) npm i
3) npm run dev
Acesse http://localhost:3000
